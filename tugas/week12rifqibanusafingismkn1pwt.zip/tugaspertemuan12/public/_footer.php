<footer class="w-full flex justify-center fixed bottom-4">
    <div class="bg-white rounded-xl">
        <h2 class="text-xl p-3 font-bold">
            Copyright Rifqi Banu Safingi <?php echo date('Y'); ?>
        </h2>
    </div>
</footer>