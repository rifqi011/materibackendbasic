<?php
header('Location: ../index');