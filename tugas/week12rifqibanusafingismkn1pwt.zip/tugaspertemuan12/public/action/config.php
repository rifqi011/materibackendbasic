<?php
define('NOMOR_HP', '08123456789');
define('PASSWORD', '123456');

header('Location: ../login');
