/** @type {import('tailwindcss').Config} */
module.exports = {
	content: ["./public/**/*.{html,js,php}", "./public/_footer.php"],
	theme: {
		extend: {},
	},
	plugins: [],
};
