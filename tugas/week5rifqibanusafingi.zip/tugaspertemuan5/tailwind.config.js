module.exports = {
    theme: {
        extend: {
            fontFamily: {
                poppins: ["Poppins"],
            },
        },
    },
};
